#
# Regular cron jobs for the info6005cw1er2g11 package
#
0 4	* * *	root	[ -x /usr/bin/info6005cw1er2g11_maintenance ] && /usr/bin/info6005cw1er2g11_maintenance
