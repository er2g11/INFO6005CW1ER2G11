?package(info6005cw1er2g11):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="info6005cw1er2g11" command="/usr/bin/info6005cw1er2g11"
